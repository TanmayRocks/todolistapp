### Contributing

Issues are currently disabled.

Please use the pull requests tab only for translations or bug fixes.