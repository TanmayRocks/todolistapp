package com.omgodse.notally.room

enum class Folder { NOTES, DELETED, ARCHIVED }