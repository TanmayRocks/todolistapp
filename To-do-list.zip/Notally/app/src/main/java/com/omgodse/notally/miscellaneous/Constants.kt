package com.omgodse.notally.miscellaneous

object Constants {
    const val SelectedLabel = "SelectedLabel"
    const val SelectedBaseNote = "SelectedBaseNote"

    const val RequestCodeExportFile = 10
}