package com.omgodse.notally.room

class Header(val label: String) : Item(ViewType.HEADER)